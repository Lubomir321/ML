import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import root_mean_squared_error
from typing import Tuple

def main():
    def preprocess(filepath: str) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:

        df = pd.read_csv(filepath, parse_dates=["datetime"])

        df["hour"] = df["datetime"].dt.hour
        df["day"] = df["datetime"].dt.day
        df["month"] = df["datetime"].dt.month
        df["year"] = df["datetime"].dt.year

        df = df.drop(columns=["datetime"])

        X = df.drop(columns=["count"])
        y = df["count"]

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=2)

        return X_train.values, X_test.values, y_train.values, y_test.values


    # Preprocess the dataset
    filepath = "bike_sharing.csv"
    X_train, X_test, y_train, y_test = preprocess(filepath)

    rf = RandomForestRegressor(random_state=2)
    param_grid = {
        "n_estimators": [100, 350, 500],
        "max_features": ["log2", "auto", "sqrt"],
        "min_samples_leaf": [2, 10, 30],
    }

    grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=3, scoring="neg_root_mean_squared_error")
    grid_search.fit(X_train, y_train)

    best_model = grid_search.best_estimator_
    y_pred = best_model.predict(X_test)
    test_rmse = root_mean_squared_error(y_test, y_pred, squared=False)

    print(f"Test set RMSE: {test_rmse:.3f}")
if __name__ == '__main__':
    main()